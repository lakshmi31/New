package com.card.common;
/**
 * @author ldudhbha
 */
public class SourceDestination {
private String source;
private String port;
private String protocol;
private String destinationIP;
private String url;

/**
 * @return the source
 */
public String getSource() {
	return source;
}
/**
 * @param source the source to set
 */
public void setSource(String source) {
	this.source = source;
}
/**
 * @return the port
 */
public String getPort() {
	return port;
}
/**
 * @param port the port to set
 */
public void setPort(String port) {
	this.port = port;
}
/**
 * @return the protocol
 */
public String getProtocol() {
	return protocol;
}
/**
 * @param protocol the protocol to set
 */
public void setProtocol(String protocol) {
	this.protocol = protocol;
}
/**
 * @return the destinationIP
 */
public String getDestinationIP() {
	return destinationIP;
}
/**
 * @param destinationIP the destinationIP to set
 */
public void setDestinationIP(String destinationIP) {
	this.destinationIP = destinationIP;
}
/**
 * @return the url
 */
public String getUrl() {
	return url;
}
/**
 * @param url the url to set
 */
public void setUrl(String url) {
	this.url = url;
}
/**
 * @param source
 * @param port
 * @param protocol
 * @param destinationIP
 * @param url
 */
public SourceDestination(String source, String port, String protocol, String destinationIP, String url) {
	super();
	this.source = source;
	this.port = port;
	this.protocol = protocol;
	this.destinationIP = destinationIP;
	this.url = url;
}
/**
 * Default Constructor.
 */
public SourceDestination() {

}
/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return "SourceDestination [source=" + source + ", port=" + port + ", protocol=" + protocol + ", destinationIP="
			+ destinationIP + ", url=" + url + "]";
}



}

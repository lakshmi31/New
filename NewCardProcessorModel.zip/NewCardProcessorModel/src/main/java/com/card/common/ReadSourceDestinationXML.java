package com.card.common;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.card.constant.Constants;
import com.card.source.model.Customer;

/** Class to read the XML file to get the destination or simulator information. */
@Component
public class ReadSourceDestinationXML {
    /** Logger.*/
    private static final Logger LOG = LoggerFactory.getLogger(ReadSourceDestinationXML.class);
    /** Source Destination class initialization. */
    private SourceDestination sourceDestination = new SourceDestination();

    /** Method to give the destination system values.
     * @param customer object
     * @return URL String
     * @throws SAXException exception thrown
     * @throws IOException exception thrown
     * @throws ParserConfigurationException exception thrown
     * @throws TransformerException exception thrown */
    public String readXML(Customer customer) throws SAXException, IOException, ParserConfigurationException,
            TransformerException {
        LOG.info("Inside readXML method");
        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        File file = new ClassPathResource(Constants.SOURCE_DESTINATION_FILE_NAME).getFile();
        Document document = docBuilder.parse(file);

        NodeList nodeList = document.getElementsByTagName(Constants.ELEMENT_TAG_NAME);

        for (int i = 0; i < nodeList.getLength(); i++) {

            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {

                Element element = (Element) node;
                if (customer.getSourceIdentifier().equalsIgnoreCase(element.getElementsByTagName(
                        Constants.ELEMENT_TAG_NAME_SOURCE).item(0).getTextContent())) {
                    sourceDestination.setProtocol(element.getElementsByTagName(Constants.ELEMENT_TAG_NAME_PROTOCOL)
                            .item(0).getTextContent());
                    sourceDestination.setPort(element.getElementsByTagName(Constants.ELEMENT_TAG_NAME_PORT).item(0)
                            .getTextContent());
                    sourceDestination.setDestinationIP(element.getElementsByTagName(Constants.ELEMENT_TAG_NAME_DESTIP)
                            .item(0).getTextContent());
                }
            }
        }

        LOG.info("URL is: " + sourceDestination.getProtocol() + ":" + sourceDestination.getPort() + ":"
                + sourceDestination.getDestinationIP() + "?jmsMessageType=Text");
        if(customer.getSourceIdentifier().equals(Constants.DESTINATION_NAME_JMS)){
        sourceDestination.setUrl(sourceDestination.getProtocol() + ":" + sourceDestination.getPort() + ":"
                + sourceDestination.getDestinationIP() + "?jmsMessageType=Text");
        }else if(customer.getSourceIdentifier().equals(Constants.DESTINATION_NAME_TCP)){
            sourceDestination.setUrl("mina2:"+sourceDestination.getProtocol() + "://" + sourceDestination.getDestinationIP() + ":"
                    + sourceDestination.getPort() + "?sync=true&textline=true");
        }

        return sourceDestination.getUrl();

    }
}

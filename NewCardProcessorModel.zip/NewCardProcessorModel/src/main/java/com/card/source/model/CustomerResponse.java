package com.card.source.model;

public class CustomerResponse {
	private String errorCode;
	private String SuccessMessage;
	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * @return the successMessage
	 */
	public String getSuccessMessage() {
		return SuccessMessage;
	}
	/**
	 * @param successMessage the successMessage to set
	 */
	public void setSuccessMessage(String successMessage) {
		SuccessMessage = successMessage;
	}
	public CustomerResponse() {
	
	}
	public CustomerResponse(String errorCode, String successMessage) {
		super();
		this.errorCode = errorCode;
		SuccessMessage = successMessage;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return errorCode + "" + SuccessMessage;
	}
	
}

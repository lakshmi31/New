package com.card.router;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import com.card.constant.Constants;
import com.card.destination.model.CustomerResponseDest;
import com.card.processor.MyConsumerProcessor;
import com.card.processor.MyProducerProcessor;
import com.card.source.model.Customer;

/** Consumer router to route message from ProcessorModel to Simulator.
 * 
 * @author ldudhbha */
@Component
public class Router extends RouteBuilder {
    /** Router configure method. */
    @Override
    public void configure() throws Exception {

        from(Constants.TIMER).to(Constants.SOURCE_URL_TO_CONSUME).unmarshal().json(JsonLibrary.Jackson, Customer.class)
                .process(new MyConsumerProcessor()).log("before endpoint:${body}").recipientList(header("urlDynamic"))
                .inOut().marshal().json(JsonLibrary.Jackson,
                        CustomerResponseDest.class).log("Marshalled data:${body}").process(new MyProducerProcessor()).log(
                                "Response body:${body}").to(Constants.SOURCE_URL_TO_PRODUCE);

        /*from(Constants.TIMER).bean(ReadSourceDestinationXML.class).recipientList(header("urlDynamic")).log("Response body:${body}").marshal().json(JsonLibrary.Jackson,
                CustomerResponseDest.class).log("Marshalled data:${body}").process(new MyProducerProcessor()).log(
                        "Response body:${body}").to(Constants.SOURCE_URL_TO_PRODUCE);*/

    }

}

package com.card.dozer;

import java.util.Arrays;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.card.constant.Constants;
import com.card.destination.model.CustomerDestination;
import com.card.destination.model.CustomerResponseDest;
import com.card.source.model.Customer;
import com.card.source.model.CustomerResponse;
/** Mapping class to map source object to Destination object. */
public class DozerMapping {
    /** Logger. */
    private static final Logger LOG = LoggerFactory.getLogger(DozerMapping.class);

    /** mappingFiles initialization. */
    private List<String> mappingFiles = Arrays.asList(Constants.DOZER_MAPPING_FILE);
    /** Method produce mapped object of CustomerDestination.
     * @param customer object
     * @return customerDestination object */
    public CustomerDestination mappedObject(Customer customer) {
        DozerBeanMapper dozerBean = new DozerBeanMapper();
        dozerBean.setMappingFiles(mappingFiles);
        CustomerDestination customerDestination = dozerBean.map(customer, CustomerDestination.class);
        LOG.info("Mapped object is:" + customerDestination);
        return customerDestination;
    }
    /** Method produce mapped object of CustomerResponse.
     * @param customerDestinationResponse destination response object
     * @return customerResponse object */
    public CustomerResponse mappedObject(CustomerResponseDest customerDestinationResponse) {
        DozerBeanMapper dozerBean = new DozerBeanMapper();
        dozerBean.setMappingFiles(mappingFiles);
        CustomerResponse customerResponse = dozerBean.map(customerDestinationResponse, CustomerResponse.class);
        LOG.info("Mapped object is:" + customerResponse);
        return customerResponse;
    }
}

package com.card.destination.model;
/**
 * Customer data POJO for Response.
 * @author ldudhbha
 */
public class CustomerResponseDest {
	private String errorCode;
	private String successMessage;
	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * @return the successMessage
	 */
	public String getSuccessMessage() {
		return successMessage;
	}
	/**
	 * @param successMessage the successMessage to set
	 */
	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}
	/**
	 * default constructor.
	 */
	public CustomerResponseDest() {
	}
	/**
	 * @param errorCode
	 * @param successMessage
	 */
	public CustomerResponseDest(String errorCode, String successMessage) {
		super();
		this.errorCode = errorCode;
		this.successMessage = successMessage;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return errorCode + "" + successMessage;
	}

}

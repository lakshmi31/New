package com.card.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.card.destination.model.CustomerResponseDest;
import com.card.dozer.DozerMapping;
import com.card.source.model.CustomerResponse;
/** Processor class to send response back to source.
 * @author ldudhbha */
public class MyProducerProcessor implements Processor {
    /** Logger. */
    private static final Logger LOG = LoggerFactory.getLogger(MyConsumerProcessor.class);
    /** dozerMapping initialization. */
    private DozerMapping dozerMapping = new DozerMapping();
    /** Method returns the destination customer object.
     * @param exchange message in exchange
     * @throws Exception exception thrown */
    public void process(Exchange exchange) throws Exception {
        LOG.info("In Processor:" + exchange.getIn().getBody());
        
        CustomerResponseDest customerDestinationResponse = (CustomerResponseDest) exchange.getIn().getBody();
       /* CustomerResponseDest customerDestinationResponse=new CustomerResponseDest();
        customerDestinationResponse.setSuccessMessage(exchange.getIn().getBody().toString()); */  
        CustomerResponse customerResponse = dozerMapping.mappedObject(customerDestinationResponse);
        exchange.getOut().setBody(customerResponse);
    }
}
